<?php

namespace Illuminate\Foundation\Testing;

use PHPUnit_Framework_ExpectationFailedException;

class HttpException extends PHPUnit_Framework_ExpectationFailedException
{
    //
}
